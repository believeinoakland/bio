---
format: bio-case-document/6
case_id: CASE-2026-0001
case_edition: 2
case_project: PROJ-2026-0001-parks
case_scope: "Who approved the lease, and on what record."
bias_acknowledgement: "We expected the board to defer to the vendor."
bias_manifest:
  in_force: false
  stated: "no manifest was in force"
  pins_proposed: 0
  pins_proposed_stated: "no adoption pinned a proposed revision"
bias_manifest_bundles: []
bias_manifest_pins_proposed: []
lens_statements: []
lens_citations: []
what_changed:
  statement_sha: "55f3e346deb058a3e5261ec1cb3c2dc329f0463797823bcaf34672bdc46e3ee3"
  began_as: "member"
  draft: null
  adopted_as_drafted: null
case_citations:
  - target: "INFO-2026-0001-minutes"
    version: "pinned"
    capture: "b887ebc0d44f37975f51e8ed71eb97b0207af342945ca958e57eb012166706f2"
case_findings: [INQ-2026-0001-lease, INQ-2026-0003-context]
case_roles:
  - target: "INQ-2026-0001-lease"
    role: "load_bearing"
    version_sha: "c52cc0b1942bcd248397a4af9a49b6338651b18e7075cbd8263133c62f593cd5"
    edition: 1
  - target: "INQ-2026-0003-context"
    role: "supporting"
    version_sha: "3de6ae11ac357441eb3a372d38c0c91ba5cd41a69f2d3affb4001699c4151105"
    edition: 1
case_tensions: []
case_tension_sentences: []
case_tensions_unread: []
capture_accounts:
  - capture: "b887ebc0d44f37975f51e8ed71eb97b0207af342945ca958e57eb012166706f2"
    by: "alice"
    at: "2026-10-02T12:00:00Z"
    text_b64: "SSBwdWxsZWQgaXQgZnJvbSB0aGUgcmVjb3JkcyBvZmZpY2UncyBib3ggb24gdGhlIDNyZC4="
    signature_b64: "LS0tLS1CRUdJTiBTU0ggU0lHTkFUVVJFLS0tLS0KVTFOSVUwbEhBQUFBQVFBQUFETUFBQUFMYzNOb0xXVmtNalUxTVRrQUFBQWdLdWlYelVoYjV1MnF5L1pBVk5aYUY3bDhidgpoTmxma1QrL2piUEwrK0dsTUFBQUFLWW1sdkxYSmhkR2xtZVFBQUFBQUFBQUFHYzJoaE5URXlBQUFBVXdBQUFBdHpjMmd0ClpXUXlOVFV4T1FBQUFFQnRDREhHNzlKbFJpTEJKODJGM2tGakN3bXJUaWxXcXhXV0NxaVZGLzc3Tk5vSmo4UVVpSXBXNEUKOXdicXNsdUdDdWVLa2lyUWRuZzZ2Vit6ZTZ2Y3NMCi0tLS0tRU5EIFNTSCBTSUdOQVRVUkUtLS0tLQo="
  - capture: "44495ef6be159ae49b85d6b612731775fe0dbe3a7853e3ca62b983c04700a46b"
    by: "bob"
    at: "2026-10-02T12:00:00Z"
    text_b64: "QSBjbGVyayBoYW5kZWQgbWUgdGhpcyBtZW1vIGluIHBlcnNvbi4="
    signature_b64: "LS0tLS1CRUdJTiBTU0ggU0lHTkFUVVJFLS0tLS0KVTFOSVUwbEhBQUFBQVFBQUFETUFBQUFMYzNOb0xXVmtNalUxTVRrQUFBQWdKKzJ3dkdUUWtab0xiQkh6SWwvci9zcjNBLwptNk9adUNaRmttb2J0QWVlOEFBQUFLWW1sdkxYSmhkR2xtZVFBQUFBQUFBQUFHYzJoaE5URXlBQUFBVXdBQUFBdHpjMmd0ClpXUXlOVFV4T1FBQUFFQXo4YnBvL2M2VFF2SmFyWUFWTVNIYUVlUHZiNFRJa0N0KzQ4MWpvcERCRENwLzNNU3hyUDIvRFAKZTFpMnlaaHo5ZkNKRmx4RHBBSFpXOEhCN2JmaThICi0tLS0tRU5EIFNTSCBTSUdOQVRVUkUtLS0tLQo="
method:
  grading: "bio-grading/1"
  checks: "1.59.0"
materials:
  - ref: "INFO-2026-0001-minutes"
    kind: "document"
    sha: "b887ebc0d44f37975f51e8ed71eb97b0207af342945ca958e57eb012166706f2"
    text_sha: "4ff4f1b3fa51ea5397a6e350c179bc4aac4a2f5909f02944ac264771f999c269"
    origin: "https://records.example/minutes.pdf"
    archived_copy: "https://archive.example/minutes"
    included: true
    rests_under: "load_bearing"
  - ref: "INFO-2026-0002-memo"
    kind: "document"
    sha: "44495ef6be159ae49b85d6b612731775fe0dbe3a7853e3ca62b983c04700a46b"
    text_sha: "31283ad105d4985dbf5747e45d2f1ba4691ce4f4738b64aa5313450ca8c116aa"
    origin: "Withheld: the source did not consent to be named"
    archived_copy: null
    included: true
    rests_under: "load_bearing"
  - ref: "INFO-2026-0009-observation"
    kind: "observation"
    sha: "c0f8ad225154f9185b566cbfd09aa9cf2c92837321488d5af1ccbb6e4c833577"
    text_sha: null
    origin: "a member's observation"
    archived_copy: null
    included: true
    rests_under: "supporting"
material_attestations:
  - ref: "INFO-2026-0001-minutes"
    by_kind: "member"
    by: "alice"
    level: "name"
    at: "2026-10-02T12:00:00Z"
    signature: "LS0tLS1CRUdJTiBTU0ggU0lHTkFUVVJFLS0tLS0KVTFOSVUwbEhBQUFBQVFBQUFETUFBQUFMYzNOb0xXVmtNalUxTVRrQUFBQWdLdWlYelVoYjV1MnF5L1pBVk5aYUY3bDhidgpoTmxma1QrL2piUEwrK0dsTUFBQUFLWW1sdkxYSmhkR2xtZVFBQUFBQUFBQUFHYzJoaE5URXlBQUFBVXdBQUFBdHpjMmd0ClpXUXlOVFV4T1FBQUFFQnRDREhHNzlKbFJpTEJKODJGM2tGakN3bXJUaWxXcXhXV0NxaVZGLzc3Tk5vSmo4UVVpSXBXNEUKOXdicXNsdUdDdWVLa2lyUWRuZzZ2Vit6ZTZ2Y3NMCi0tLS0tRU5EIFNTSCBTSUdOQVRVUkUtLS0tLQo="
    recorded_in: null
  - ref: "INFO-2026-0001-minutes"
    by_kind: "project"
    by: "PROJ-2026-0001-parks"
    level: null
    at: "2026-10-02T12:00:00Z"
    signature: null
    recorded_in: "INFO-2026-0001-minutes"
  - ref: "INFO-2026-0001-minutes"
    by_kind: "group"
    by: "lakeshore-tenants"
    level: null
    at: null
    signature: "case"
    recorded_in: null
  - ref: "INFO-2026-0002-memo"
    by_kind: "member"
    by: "bob"
    level: "cover"
    at: "2026-10-02T12:00:00Z"
    signature: "LS0tLS1CRUdJTiBTU0ggU0lHTkFUVVJFLS0tLS0KVTFOSVUwbEhBQUFBQVFBQUFETUFBQUFMYzNOb0xXVmtNalUxTVRrQUFBQWdKKzJ3dkdUUWtab0xiQkh6SWwvci9zcjNBLwptNk9adUNaRmttb2J0QWVlOEFBQUFLWW1sdkxYSmhkR2xtZVFBQUFBQUFBQUFHYzJoaE5URXlBQUFBVXdBQUFBdHpjMmd0ClpXUXlOVFV4T1FBQUFFQXo4YnBvL2M2VFF2SmFyWUFWTVNIYUVlUHZiNFRJa0N0KzQ4MWpvcERCRENwLzNNU3hyUDIvRFAKZTFpMnlaaHo5ZkNKRmx4RHBBSFpXOEhCN2JmaThICi0tLS0tRU5EIFNTSCBTSUdOQVRVUkUtLS0tLQo="
    recorded_in: null
  - ref: "INFO-2026-0002-memo"
    by_kind: "group"
    by: "lakeshore-tenants"
    level: null
    at: null
    signature: "case"
    recorded_in: null
  - ref: "INFO-2026-0009-observation"
    by_kind: "member"
    by: null
    level: "group"
    at: "2026-10-02T12:00:00Z"
    signature: null
    recorded_in: null
grading_facts:
  - finding: '"INQ-2026-0001-lease"'
    ord: 0
    target: '"INFO-2026-0001-minutes"'
    kind: '"document"'
    role: '"supports"'
    grade: '"B"'
    grade_axis: '"capture"'
    grade_source: '"capture"'
    ground: null
    target_edition: null
    answer: null
    origins: null
    origins_complete: null
    captures: '["b887ebc0d44f37975f51e8ed71eb97b0207af342945ca958e57eb012166706f2"]'
    author_key: null
  - finding: '"INQ-2026-0001-lease"'
    ord: 1
    target: '"INQ-2026-0002-board"'
    kind: '"inquiry"'
    role: '"supports"'
    grade: null
    grade_axis: null
    grade_source: '"inherited"'
    ground: null
    target_edition: null
    answer: '{"capture":{"grade":"B","state":"graded"},"connection":{"grade":"B","state":"graded"},"testimony":{"grade":null,"state":"unrated"}}'
    origins: null
    origins_complete: null
    captures: null
    author_key: null
  - finding: '"INQ-2026-0002-board"'
    ord: 0
    target: '"INFO-2026-0001-minutes"'
    kind: '"document"'
    role: '"supports"'
    grade: '"B"'
    grade_axis: '"capture"'
    grade_source: '"capture"'
    ground: null
    target_edition: null
    answer: null
    origins: null
    origins_complete: null
    captures: '["b887ebc0d44f37975f51e8ed71eb97b0207af342945ca958e57eb012166706f2"]'
    author_key: null
  - finding: '"INQ-2026-0002-board"'
    ord: 1
    target: '"INFO-2026-0002-memo"'
    kind: '"document"'
    role: '"supports"'
    grade: '"B"'
    grade_axis: '"connection"'
    grade_source: '"resolution"'
    ground: null
    target_edition: null
    answer: null
    origins: null
    origins_complete: null
    captures: '["44495ef6be159ae49b85d6b612731775fe0dbe3a7853e3ca62b983c04700a46b"]'
    author_key: null
  - finding: '"INQ-2026-0003-context"'
    ord: 0
    target: '"INFO-2026-0009-observation"'
    kind: '"observation"'
    role: '"supports"'
    grade: '"D"'
    grade_axis: '"testimony"'
    grade_source: '"testimony"'
    ground: null
    target_edition: null
    answer: null
    origins: null
    origins_complete: null
    captures: null
    author_key: null
passages:
  - finding: '"INQ-2026-0001-lease"'
    ord: 0
    content_id: '"5dc78431e2b1250e475fd255d84e3c9727c4be70c338627613a3a55ecd2639b3"'
    capture_sha: '"b887ebc0d44f37975f51e8ed71eb97b0207af342945ca958e57eb012166706f2"'
    extent: '{"kind":"pdf-page","page":0}'
    chain: null
    quoted: '"The lease was approved without a vote."'
completeness:
  statement: "the 2019 permits are not covered"
  author: alice
  statement_by: bob
  at: "2026-09-28T00:00:00Z"
  subject_position: not_sought
  subject_justification: "the office is closed until October"
  acknowledged: 1
completeness_acknowledgements:
  - kind: "participant"
    by: "carol"
    at: "2026-09-27T00:00:00Z"
completeness_excluded:
  - target: null
    description: "the 2019 permits"
    reason: "not yet requested"
searched:
  subject_source: case_basis
  subjects: 2
searched_levels: []
case_strength:
  - target: "INQ-2026-0001-lease"
    axis: "capture"
    state: "graded"
    grade: "B"
  - target: "INQ-2026-0001-lease"
    axis: "connection"
    state: "graded"
    grade: "B"
  - target: "INQ-2026-0001-lease"
    axis: "testimony"
    state: "unrated"
    grade: null
  - target: "INQ-2026-0003-context"
    axis: "capture"
    state: "unrated"
    grade: null
  - target: "INQ-2026-0003-context"
    axis: "connection"
    state: "unrated"
    grade: null
  - target: "INQ-2026-0003-context"
    axis: "testimony"
    state: "graded"
    grade: "D"
case_strength_grounds: []
required_strength:
  declared: true
  source: project
  capture: B
  connection: C
  detail: ""
---

# Case CASE-2026-0001 — edition 2

## What Changed in This Edition, and Why

Added the 2019 minutes.

## Scope

Who approved the lease.

## What This Excludes

the 2019 permits
